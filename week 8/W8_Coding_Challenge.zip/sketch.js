var total = 150; //total num of particles to create
var plist = []; //create an empty list to contain particles

function setup() {
  createCanvas(400, 400);
  
  for (let i = 0; i < total; i++){
    plist.push(new particle() ); //add ("push") new particle to plist
  }
}

function draw() {
  background(224,204,255);
  for (let i = 0; i < plist.length; i++){
   plist[i].display(); //run display for each particle 
  }
}


class particle{
 //variables and constructor - need x and y pos 
  constructor(){
   this.x = random (0, width);
  this.y = random (0, height);
  }
  
  display(){
   stroke(255);
    strokeWeight(2);
    point(this.x, this.y);
  
  this.x += random(-5,5);
  this.y += random(-5,5);
    
//check for boundaries
 if (this.x < 0 || this.x > width ||
     this.y < 0 || this.y > height){
   this.x = random(0,width);
   this.y = random(0,height);
 }
  }
}